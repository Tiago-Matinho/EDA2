#include "min_heap.h"


void path_insert(struct flight_list* list, struct list_node* node);
struct list_node* path_remove(struct flight_list* list);

void print_path(struct flight_list* list);